﻿namespace Crosschat.Server.Infrastructure
{
    public static class GlobalConfig
    {
        public const string IpAddress = "23.97.209.133";//"ABOT.cloudapp.net";
        public const int Port = 3452;
    }
}
