﻿namespace Crosschat.Server.Domain.Seedwork
{
    public abstract class ValueObject
    {
    }
}