﻿namespace Crosschat.Server.Domain.Repositories
{
    public interface IRepository
    {
    }
}
