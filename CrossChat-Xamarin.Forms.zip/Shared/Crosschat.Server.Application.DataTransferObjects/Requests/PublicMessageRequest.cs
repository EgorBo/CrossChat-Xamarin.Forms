﻿namespace Crosschat.Server.Application.DataTransferObjects.Requests
{
    public class PublicMessageRequest : RequestBase
    {
        public string Body { get; set; }
    }
}
