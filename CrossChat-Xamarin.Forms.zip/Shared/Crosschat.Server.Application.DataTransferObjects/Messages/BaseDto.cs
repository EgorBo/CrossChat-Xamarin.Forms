﻿namespace Crosschat.Server.Application.DataTransferObjects.Messages
{
    public class BaseDto
    {
    }
}
