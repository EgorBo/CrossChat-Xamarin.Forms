﻿namespace Crosschat.Server.Application.DataTransferObjects.Enums
{
    public enum UserRoleEnum
    {
        User,
        Moderator,
        Admin,
    }
}
