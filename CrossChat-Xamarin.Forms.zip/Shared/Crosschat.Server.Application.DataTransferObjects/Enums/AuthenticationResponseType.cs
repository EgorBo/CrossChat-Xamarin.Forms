﻿namespace Crosschat.Server.Application.DataTransferObjects.Enums
{
    public enum AuthenticationResponseType
    {
        Success,
        InvalidNameOrPassword,
    }
}