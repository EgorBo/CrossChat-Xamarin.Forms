﻿namespace Crosschat.Server.Application.DataTransferObjects.Enums
{
    public enum RegistrationResponseType
    {
        Success,
        NameIsInUse,
        InvalidData,
    }
}