CrossChat
============

A simple chat application without back-end, all conversations work in "echo" mode. The application is built using Xamarin.Forms with MVVM approach.

Authors
-------

Egor Bogatov
