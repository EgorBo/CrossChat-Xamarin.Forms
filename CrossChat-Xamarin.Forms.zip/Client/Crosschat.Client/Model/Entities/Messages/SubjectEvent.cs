﻿namespace Crosschat.Client.Model.Entities.Messages
{
    public class SubjectEvent : Event
    {
        public string Subject { get; set; }
    }
}
