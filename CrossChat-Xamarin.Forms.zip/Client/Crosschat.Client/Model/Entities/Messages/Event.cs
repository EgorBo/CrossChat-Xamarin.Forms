﻿namespace Crosschat.Client.Model.Entities.Messages
{
    public class Event
    {
    }
}